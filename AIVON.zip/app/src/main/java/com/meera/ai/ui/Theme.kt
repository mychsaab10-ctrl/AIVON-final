package com.meera.ai.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF7AB8FF)
val Purple = Color(0xFF9B6CFF)
val Pink = Color(0xFFC77DFF)
val DeepBg = Color(0xFF04061A)

/** true while the dark (glass) theme is active. */
val LocalDark = compositionLocalOf { true }

private val DarkScheme = darkColorScheme(
    primary = Cyan, onPrimary = Color.Black,
    secondary = Purple, tertiary = Pink,
    background = DeepBg, onBackground = Color(0xFFEAE8FF),
    surface = Color(0xFF0A0F2E), onSurface = Color(0xFFEAE8FF),
    surfaceVariant = Color(0xFF141B48), onSurfaceVariant = Color(0xFFB4BCEB),
    outline = Color(0xFF3A3F94), error = Color(0xFFFF6B81)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF0891B2), onPrimary = Color.White,
    secondary = Color(0xFF7C3AED), tertiary = Color(0xFFDB2777),
    background = Color(0xFFF7F4FF), onBackground = Color(0xFF1B1530),
    surface = Color.White, onSurface = Color(0xFF1B1530),
    surfaceVariant = Color(0xFFEDE7FF), onSurfaceVariant = Color(0xFF5B4F7A),
    outline = Color(0xFFB9ADD6), error = Color(0xFFD6334D)
)

/** mode: "dark" | "light" | "system" */
@Composable
fun MeeraTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "light" -> false
        "system" -> isSystemInDarkTheme()
        else -> true
    }
    CompositionLocalProvider(LocalDark provides dark) {
        MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
    }
}
