package com.meera.ai.ui.orb

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.meera.ai.ui.LocalDark
import kotlin.math.min

/** Styles that use many particles or lines: they are limited to about 30 frames per second. */
private val HEAVY_STYLES = setOf(2, 7, 10, 15, 16, 19)

internal fun DrawScope.drawOrbStyle(style: Int, f: OrbFrame) {
    when (style) {
        0 -> sSimple(f)
        1 -> sPlasma(f)
        2 -> sHacker(f)
        3 -> sLiquid(f)
        4 -> sHalo(f)
        5 -> sWaves(f)
        6 -> sGold(f)
        7 -> sNebula(f)
        8 -> sCrystal(f)
        9 -> sSonar(f)
        10 -> sGlobe(f)
        11 -> sBars(f)
        12 -> sSilk(f)
        13 -> sBubbles(f)
        14 -> sEcg(f)
        15 -> sGyro(f)
        16 -> sBolt(f)
        17 -> sFlare(f)
        18 -> sMandala(f)
        19 -> sSynth(f)
        else -> sPlasma(f)
    }
}

/**
 * The AIVON voice orb. simulate = true always uses a made-up voice level (previews, Test button);
 * simulate = false follows Meera's real voice during a call.
 */
@Composable
fun OrbView(state: OrbState, cfg: OrbConfig, modifier: Modifier = Modifier, simulate: Boolean = false) {
    val mem = remember { OrbMemory() }
    val owner = LocalLifecycleOwner.current
    var active by remember { mutableStateOf(true) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_START || e == Lifecycle.Event.ON_RESUME) active = true
            else if (e == Lifecycle.Event.ON_STOP) active = false
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    var tick by remember { mutableStateOf(0L) }
    val gap = if (cfg.lowFx) 50_000_000L else if (cfg.style in HEAVY_STYLES) 33_000_000L else 0L
    LaunchedEffect(active, gap) {
        if (active) {
            var last = 0L
            while (true) {
                androidx.compose.runtime.withFrameNanos { n ->
                    if (n - last >= gap) {
                        last = n
                        tick = n
                    }
                }
            }
        }
    }
    val dark = LocalDark.current
    Canvas(modifier) {
        val now = tick
        val side = min(size.width, size.height)
        if (side < 2f) return@Canvas
        mem.step(now, state, cfg, simulate)
        val bgColor: Color? = when (cfg.bg) {
            0 -> Color.Black
            2 -> Color(0xFF0A0F2C)
            else -> if (dark) null else Color.Black
        }
        if (bgColor != null) {
            drawRoundRect(
                bgColor, Offset((size.width - side) / 2f, (size.height - side) / 2f), Size(side, side),
                CornerRadius(20.dp.toPx())
            )
        }
        val k = side / 340f * cfg.size
        val frame = OrbFrame(mem.t, mem.lvl, mem.rot, state, orbPalette(cfg), hackerColor(cfg), cfg.glow, cfg.lowFx, mem)
        withTransform({
            translate(size.width / 2f, size.height / 2f)
            scale(k, k, Offset.Zero)
        }) {
            drawOrbStyle(cfg.style, frame)
        }
    }
}
