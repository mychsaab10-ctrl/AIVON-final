package com.meera.ai.ui

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

private fun hasInternet(ctx: Context): Boolean {
    val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return true
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/** true while the phone has a working network (updates live). */
@Composable
fun rememberOnline(): State<Boolean> {
    val ctx = LocalContext.current
    val s = remember { mutableStateOf(hasInternet(ctx)) }
    DisposableEffect(Unit) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { s.value = true }
            override fun onLost(network: Network) { s.value = hasInternet(ctx) }
        }
        try { cm?.registerDefaultNetworkCallback(cb) } catch (e: Exception) {}
        onDispose { try { cm?.unregisterNetworkCallback(cb) } catch (e: Exception) {} }
    }
    return s
}
