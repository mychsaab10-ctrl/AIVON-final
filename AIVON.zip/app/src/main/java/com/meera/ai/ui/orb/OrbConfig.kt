package com.meera.ai.ui.orb

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.meera.ai.Meera
import com.meera.ai.voice.CallState
import kotlin.math.floor

enum class OrbState { IDLE, LISTEN, THINK, SPEAK }

fun CallState.toOrb(): OrbState = when (this) {
    CallState.Speaking -> OrbState.SPEAK
    CallState.Listening -> OrbState.LISTEN
    CallState.Thinking, CallState.Connecting -> OrbState.THINK
    else -> OrbState.IDLE
}

/** Everything the orb needs, in one immutable object (colours are ARGB Ints). */
data class OrbConfig(
    val style: Int = 1,
    val palette: Int = 0,
    val colA: Int = 0xFF8C6EFF.toInt(),
    val colB: Int = 0xFF3CD7F0.toInt(),
    val colC: Int = 0xFFFF82C8.toInt(),
    val colL: Int = 0xFFFFD68C.toInt(),
    val gain: Float = 1f,
    val speed: Float = 1f,
    val glow: Float = 1f,
    val size: Float = 1f,
    val bg: Int = 1,
    val lowFx: Boolean = false
)

fun orbConfigFromSettings(): OrbConfig {
    val s = Meera.settings
    return OrbConfig(
        style = s.orbStyle.coerceIn(0, ORB_STYLE_NAMES.size - 1),
        palette = s.orbPalette.coerceIn(0, 4),
        colA = s.orbColA, colB = s.orbColB, colC = s.orbColC, colL = s.orbColL,
        gain = s.orbGain.coerceIn(0.3f, 1.6f),
        speed = s.orbSpeed.coerceIn(0.5f, 2f),
        glow = s.orbGlow.coerceIn(0f, 1.5f),
        size = s.orbSize.coerceIn(0.7f, 1.2f),
        bg = s.orbBg.coerceIn(0, 2),
        lowFx = s.orbLowFx
    )
}

val ORB_STYLE_NAMES = listOf(
    "Simple Orb", "Plasma Orb", "Hacker HUD", "Liquid Aura", "Halo Ring",
    "Aurora Waves", "Gold Luxe", "Nebula", "Crystal Prism", "Sonar",
    "Dot Globe", "Spectrum Bars", "Silk Ribbons", "Bubbles", "ECG Pulse",
    "Gyroscope", "Plasma Bolt", "Solar Flare", "Mandala", "Synthwave Grid"
)

val ORB_PALETTE_NAMES = listOf("Aurora", "Sunset", "Ocean", "Emerald", "Custom")

class OrbPal(val a: Color, val b: Color, val c: Color, val l: Color) {
    /** Cycles a -> b -> c -> a for k in 0..1 (any float, it wraps). */
    fun tri(k0: Float): Color {
        val k = k0 - floor(k0)
        return when {
            k < 1f / 3f -> lerp(a, b, k * 3f)
            k < 2f / 3f -> lerp(b, c, (k - 1f / 3f) * 3f)
            else -> lerp(c, a, (k - 2f / 3f) * 3f)
        }
    }
}

private fun rgb(r: Int, g: Int, b: Int) = Color(r / 255f, g / 255f, b / 255f, 1f)

private val READY = listOf(
    OrbPal(rgb(140, 110, 255), rgb(60, 215, 240), rgb(255, 130, 200), rgb(255, 214, 140)),
    OrbPal(rgb(255, 140, 70), rgb(255, 100, 150), rgb(170, 110, 255), rgb(240, 170, 150)),
    OrbPal(rgb(70, 140, 255), rgb(40, 220, 200), rgb(210, 235, 255), rgb(205, 220, 240)),
    OrbPal(rgb(50, 215, 140), rgb(190, 240, 90), rgb(60, 210, 230), rgb(200, 230, 190))
)

/** Palette 0..3 = ready sets, 4 = custom colours from the settings. */
fun orbPalette(cfg: OrbConfig): OrbPal =
    if (cfg.palette in 0..3) READY[cfg.palette]
    else OrbPal(Color(cfg.colA), Color(cfg.colB), Color(cfg.colC), Color(cfg.colL))

val HACKER_COLORS = listOf(rgb(0, 255, 120), rgb(0, 230, 255), rgb(255, 60, 80), rgb(190, 100, 255))

fun hackerColor(cfg: OrbConfig): Color =
    if (cfg.palette in 0..3) HACKER_COLORS[cfg.palette] else Color(cfg.colA)

/** The 4 palette swatch colours (first two) used by the picker. */
fun orbSwatch(index: Int, cfg: OrbConfig): Pair<Color, Color> {
    val p = if (index in 0..3) READY[index] else OrbPal(Color(cfg.colA), Color(cfg.colB), Color(cfg.colC), Color(cfg.colL))
    return Pair(p.a, p.b)
}
