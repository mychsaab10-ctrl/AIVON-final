package com.meera.ai.ui.orb

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

// ───────────────────────── 10  Dot Globe ─────────────────────────
internal fun DrawScope.sGlobe(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    val m = f.mem
    glow(f, 0f, 0f, 140f, p.a, 0.1f + lvl * 0.14f)
    val r = 64f
    val step = if (f.low) 2 else 1
    val sph = m.sphere420
    val tp = m.tmp420
    var i = 0
    while (i < 420) {
        val q = sph[i]
        val lat = q[1]
        val d = when {
            f.speak -> lvl * 0.28f * sin(lat * 9f - t * 9f)
            f.listen -> lvl * 0.12f * sin(lat * 6f - t * 4f)
            f.think -> 0.06f * sin(lat * 14f - t * 8f)
            else -> 0f
        }
        rotYX(q[0], q[1], q[2], f.rot, 0.35f, tp, i * 3)
        val s = r * (1f + d)
        tp[i * 3] = tp[i * 3] * s
        tp[i * 3 + 1] = tp[i * 3 + 1] * s
        tp[i * 3 + 2] = (tp[i * 3 + 2] + 1f) / 2f
        i += step
    }
    for (pass in 0..3) {
        var j = 0
        while (j < 420) {
            val z = tp[j * 3 + 2]
            if ((z * 4f).toInt().coerceIn(0, 3) == pass) {
                val col = p.tri((sph[j][1] + 1f) / 2f * 0.9f + f.rot * 0.05f)
                drawCircle(col.mixW(z * 0.4f).al(0.18f + 0.8f * z), 0.9f + 1.6f * z, Offset(tp[j * 3], tp[j * 3 + 1]))
            }
            j += step
        }
    }
}

// ───────────────────────── 11  Spectrum Bars ─────────────────────────
internal fun DrawScope.sBars(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    glow(f, 0f, 0f, 150f, p.a, 0.06f + lvl * 0.1f)
    val bars = f.mem.bars
    for (i in 0 until 27) {
        val dist = abs(i - 13) / 13f
        val h = when {
            f.speak -> 6f + lvl * 150f * (0.3f + 0.7f * abs(sin(i * 0.7f + t * 7f) * sin(i * 0.23f - t * 3.1f))) * (1f - 0.55f * dist)
            f.listen -> 6f + lvl * 60f * (0.5f + 0.5f * sin(i * 0.5f + t * 3f)) * (1f - 0.5f * dist)
            f.think -> 6f + 34f * max(0f, sin(t * 3f - i * 0.45f))
            else -> 6f + 3f * sin(i * 0.5f + t)
        }
        bars[i] = bars[i] + (h - bars[i]) * 0.35f
        val x = -156f + i * 12f
        val half = max(0f, min(bars[i], 170f) / 2f - 4f)
        val col = p.tri(i / 27f + f.rot * 0.05f)
        if (!f.low) drawLine(col.al(0.1f * f.glow), Offset(x, -half), Offset(x, half), 15f, StrokeCap.Round, blendMode = BlendMode.Plus)
        drawLine(col.mixW(0.1f).al(0.95f), Offset(x, -half), Offset(x, half), 8f, StrokeCap.Round)
    }
}

// ───────────────────────── 12  Silk Ribbons ─────────────────────────
internal fun DrawScope.sSilk(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    glow(f, 0f, 0f, 130f, p.a, 0.1f + lvl * 0.15f)
    val amp = 14f + lvl * (if (f.speak) 46f else 14f)
    val path = f.mem.path
    val stp = if (f.low) 3 else 1
    for (k in 0..5) {
        val col = p.tri(k / 6f + f.rot * 0.05f)
        val dir = if (k % 2 == 1) 1f else -1f
        path.reset()
        var a = 0
        while (a <= 180) {
            val th = a / 180f * TAU
            val r = 58f + k * 3f + amp * (0.6f * sin(3f * th + t * (0.8f + k * 0.2f) + k) + 0.4f * sin(5f * th - t * 1.1f + k * 1.3f))
            val an = th + f.rot * 0.3f * dir
            val x = cos(an) * r
            val y = sin(an) * r * 0.92f
            if (a == 0) path.moveTo(x, y) else path.lineTo(x, y)
            a += stp
        }
        path.close()
        if (!f.low) drawPath(path, col.al(0.07f * f.glow), style = Stroke(7f), blendMode = BlendMode.Plus)
        drawPath(path, col.al(0.8f), style = Stroke(1.6f), blendMode = BlendMode.Plus)
    }
}

// ───────────────────────── 13  Bubbles ─────────────────────────
private fun DrawScope.bubble(x: Float, y: Float, r: Float, col: Color, a: Float) {
    val c = Offset(x, y)
    drawCircle(
        Brush.radialGradient(
            0f to col.al(0.04f * a), 0.75f to col.al(0.14f * a), 1f to col.mixW(0.4f).al(0.55f * a),
            center = c, radius = r
        ), r, c
    )
    drawCircle(Color.White.copy(alpha = (0.3f * a).coerceIn(0f, 1f)), r, c, style = Stroke(1f))
    rotate(-34f, Offset(x - r * 0.38f, y - r * 0.42f)) {
        drawOval(Color.White.copy(alpha = (0.55f * a).coerceIn(0f, 1f)), Offset(x - r * 0.6f, y - r * 0.54f), Size(r * 0.44f, r * 0.24f))
    }
}

internal fun DrawScope.sBubbles(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    glow(f, 0f, 0f, 150f, p.a, 0.08f + lvl * 0.12f)
    val n = if (f.low) 7 else 12
    for (i in 0 until n) {
        val dir = if (i % 2 == 1) 1f else -1f
        val a = i * 0.52f + f.rot * (0.3f + (i % 3) * 0.1f) * dir * 2f
        val rr = (30f + (i * 29) % 70) * (1f + (if (f.speak) 0.3f * lvl else 0.08f * lvl))
        val sz = (12f + (i * 7) % 16) * (1f + (if (f.speak) 0.6f * lvl * abs(sin(i + t * 6f)) else 0.1f * lvl))
        bubble(cos(a) * rr, sin(a) * rr * 0.92f, sz, p.tri(i / 12f), 1f)
    }
    val r = 40f * (1f + lvl * 0.2f)
    glow(f, 0f, 0f, r * 1.8f, p.b, 0.18f + lvl * 0.2f)
    bubble(0f, 0f, r, p.a.mixW(0.2f), 1.3f)
}

// ───────────────────────── 14  ECG Pulse ─────────────────────────
private fun gauss(x: Float, m: Float, s: Float): Float {
    val z = (x - m) / s
    return exp(-z * z / 2f)
}

internal fun DrawScope.sEcg(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    val e = f.mem.ecg
    val x0 = -150f
    var gx = 0
    while (gx <= 300) { drawLine(Color.White.copy(alpha = 0.08f), Offset(x0 + gx, -100f), Offset(x0 + gx, 100f), 1f); gx += 20 }
    var gy = -100
    while (gy <= 100) { drawLine(Color.White.copy(alpha = 0.08f), Offset(x0, gy.toFloat()), Offset(x0 + 300f, gy.toFloat()), 1f); gy += 20 }
    val period = when { f.speak -> 0.55f; f.think -> 0.7f; f.listen -> 1.2f; else -> 1.6f }
    val amp = when { f.speak -> 0.5f + lvl * 1.3f; f.think -> 0.9f; f.listen -> 0.6f; else -> 0.35f }
    val ph = (t / period) % 1f
    var v = (10f * gauss(ph, 0.12f, 0.03f) - 18f * gauss(ph, 0.26f, 0.01f) + 80f * gauss(ph, 0.30f, 0.01f) -
        25f * gauss(ph, 0.34f, 0.012f) + 16f * gauss(ph, 0.55f, 0.05f)) * amp * 1.1f
    if (f.speak) v += lvl * 14f * sin(60f * t)
    System.arraycopy(e, 1, e, 0, 149)
    e[149] = v
    val col = p.tri(0.2f)
    for (i in 1 until 150) {
        val k = i / 150f
        val ya = -e[i - 1].coerceIn(-95f, 95f)
        val yb = -e[i].coerceIn(-95f, 95f)
        val xa = x0 + (i - 1) * 2f
        val xb = x0 + i * 2f
        if (!f.low) drawLine(col.al(0.1f * k * f.glow), Offset(xa, ya), Offset(xb, yb), 7f, StrokeCap.Round, blendMode = BlendMode.Plus)
        drawLine(col.mixW(0.35f).al(0.9f * k), Offset(xa, ya), Offset(xb, yb), 2f, StrokeCap.Round)
    }
    val hy = -e[149].coerceIn(-95f, 95f)
    glow(f, x0 + 298f, hy, 16f, col.mixW(0.5f), 0.8f)
    drawCircle(Color.White, 2.4f, Offset(x0 + 298f, hy))
}

// ───────────────────────── 15  Gyroscope ─────────────────────────
internal fun DrawScope.sGyro(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    glow(f, 0f, 0f, 140f, p.a, 0.07f + lvl * 0.12f)
    val r = 82f * (1f + lvl * 0.12f)
    val tp = FloatArray(3)
    val seg = if (f.low) 48 else 90
    for (k in 0..2) {
        val ay = f.rot * (0.5f + k * 0.2f)
        val ax = f.rot * (0.7f + k * 0.3f) + k * 1.05f
        val col = p.tri(k / 3f)
        var px = 0f
        var py = 0f
        for (i in 0..seg) {
            val ph = i.toFloat() / seg * TAU
            rotYX(cos(ph), sin(ph), 0f, ay, ax, tp, 0)
            val kk = 300f / (300f - tp[2] * r)
            val x = tp[0] * r * kk
            val y = tp[1] * r * kk
            if (i > 0) drawLine(col.mixW(0.2f).al(0.2f + 0.7f * (tp[2] + 1f) / 2f), Offset(px, py), Offset(x, y), 2.4f + lvl * 4f, StrokeCap.Round)
            px = x
            py = y
        }
        val eph = t * (1.5f + k * 0.7f)
        rotYX(cos(eph), sin(eph), 0f, ay, ax, tp, 0)
        val ek = 300f / (300f - tp[2] * r)
        val ex = tp[0] * r * ek
        val ey = tp[1] * r * ek
        glow(f, ex, ey, 12f, col.mixW(0.5f), 0.9f)
        drawCircle(Color.White, 2.6f, Offset(ex, ey))
    }
    glow(f, 0f, 0f, 14f + lvl * 26f, p.b.mixW(0.5f), 0.8f)
    drawCircle(Color.White.copy(alpha = 0.9f), 4f + lvl * 5f, Offset.Zero)
}

// ───────────────────────── 16  Plasma Bolt ─────────────────────────
internal fun DrawScope.sBolt(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    drawCircle(p.a.al(0.04f), 100f, Offset.Zero)
    drawCircle(p.b.mixW(0.4f).al(0.28f), 100f, Offset.Zero, style = Stroke(1.4f))
    drawArc(Color.White.copy(alpha = 0.22f), 206f, 52f, false, Offset(-94f, -94f), Size(188f, 188f), style = Stroke(1f))
    glow(f, 0f, 0f, 60f + lvl * 50f, p.a, 0.28f + lvl * 0.2f)
    val nb = if (f.speak) 3 + (lvl * 8f).roundToInt() else if (f.think) 5 else 2
    val slice = floor(t * (if (f.think) 18f else 10f))
    val path = f.mem.path
    val rnd = f.mem.rnd
    for (i in 0 until nb) {
        val ang = hash01(i * 7.3f + slice) * TAU
        path.reset()
        path.moveTo(0f, 0f)
        var x = 0f
        var y = 0f
        for (s in 1..9) {
            val fr = s / 9f
            val j = (rnd.nextFloat() - 0.5f) * 24f * (1f - fr * 0.3f)
            x = cos(ang) * 98f * fr + cos(ang + 1.5708f) * j
            y = sin(ang) * 98f * fr + sin(ang + 1.5708f) * j
            path.lineTo(x, y)
        }
        drawPath(path, p.b.al(0.14f), style = Stroke(6f, join = StrokeJoin.Round), blendMode = BlendMode.Plus)
        drawPath(path, p.b.mixW(0.3f).al(0.55f), style = Stroke(2.4f, join = StrokeJoin.Round), blendMode = BlendMode.Plus)
        drawPath(path, Color.White.copy(alpha = 0.95f), style = Stroke(1f, join = StrokeJoin.Round))
        glow(f, x, y, 14f, p.c.mixW(0.4f), 0.5f)
    }
    glow(f, 0f, 0f, 26f + lvl * 20f, Color.White, 0.7f)
    drawCircle(Color.White, 5f + lvl * 6f, Offset.Zero)
}

// ───────────────────────── 17  Solar Flare ─────────────────────────
private fun DrawScope.rays(f: OrbFrame, n: Int, r0: Float, base: Float, amp: Float, dirn: Float, alpha: Float, w: Float) {
    val path = f.mem.path
    for (i in 0 until n) {
        val a = i.toFloat() / n * TAU + f.rot * 0.5f * dirn
        val len = if (f.speak) base + f.lvl * amp * (0.4f + 0.6f * abs(sin(i * 1.3f + f.t * 5f))) else base + amp * 0.1f * sin(i * 0.7f + f.t * 2f)
        val r1 = r0 + len
        val col = f.pal.tri(i.toFloat() / n + f.rot * 0.05f)
        path.reset()
        path.moveTo(cos(a - w) * r0, sin(a - w) * r0)
        path.lineTo(cos(a) * r1, sin(a) * r1)
        path.lineTo(cos(a + w) * r0, sin(a + w) * r0)
        path.close()
        drawPath(path, col.al(alpha), blendMode = BlendMode.Plus)
    }
}

internal fun DrawScope.sFlare(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    glow(f, 0f, 0f, 150f, p.a, 0.1f + lvl * 0.14f)
    rays(f, if (f.low) 18 else 36, 42f, 20f, 55f, 1f, 0.55f, 0.07f)
    rays(f, if (f.low) 9 else 18, 42f, 34f, 70f, -1f, 0.3f, 0.05f)
    val r = 34f * (1f + lvl * 0.25f)
    drawCircle(
        Brush.radialGradient(0f to Color.White, 0.5f to p.b.mixW(0.3f), 1f to p.a, center = Offset.Zero, radius = r),
        r, Offset.Zero
    )
    drawCircle(p.b.mixW(0.3f).al(0.6f), r + 8f, Offset.Zero, style = Stroke(1.6f), blendMode = BlendMode.Plus)
    glow(f, 0f, 0f, r * 2f, p.b, 0.25f + lvl * 0.2f)
}

// ───────────────────────── 18  Mandala ─────────────────────────
internal fun DrawScope.sMandala(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    glow(f, 0f, 0f, 140f, p.a, 0.1f + lvl * 0.12f)
    for (l in 0..2) {
        val rl = 30f + l * 24f
        val ra = (26f + l * 10f) * (1f + lvl * 0.4f)
        val rb = 8f + l * 3f + lvl * 4f
        val dir = if (l % 2 == 1) -1f else 1f
        for (i in 0 until 12) {
            val a = i / 12f * TAU + f.rot * 0.25f * dir + l * 0.26f
            val x = cos(a) * rl
            val y = sin(a) * rl
            val col = p.tri(i / 12f + l * 0.2f + f.rot * 0.03f)
            rotate(a * RAD2DEG, Offset(x, y)) {
                drawOval(col.al(0.05f + lvl * 0.05f), Offset(x - ra, y - rb), Size(2f * ra, 2f * rb))
                drawOval(col.mixW(0.3f).al(0.55f), Offset(x - ra, y - rb), Size(2f * ra, 2f * rb), style = Stroke(1.3f))
            }
        }
    }
    val nd = if (f.low) 18 else 36
    for (i in 0 until nd) {
        val a = i.toFloat() / nd * TAU - f.rot * 0.2f
        val tw = 0.5f + 0.5f * sin(t * 2f + i)
        drawCircle(p.tri(i.toFloat() / nd).mixW(0.4f).al(0.25f + 0.5f * tw), 1.6f, Offset(cos(a) * 126f, sin(a) * 126f))
    }
    glow(f, 0f, 0f, 10f + lvl * 24f, Color.White, 0.7f)
    drawCircle(Color.White.copy(alpha = 0.95f), 3f + lvl * 4f, Offset.Zero)
}

// ───────────────────────── 19  Synthwave Grid ─────────────────────────
internal fun DrawScope.sSynth(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    val m = f.mem
    drawRect(Color.Black, Offset(-170f, -170f), Size(340f, 340f))
    val h = 5f
    for (i in 0 until 24) {
        val tw = 0.5f + 0.5f * sin(t * 1.5f + i)
        drawRect(Color.White.copy(alpha = 0.2f + 0.5f * tw), Offset(((i * 53) % 340) - 170f, -170f + (i * 37) % 110), Size(1.6f, 1.6f))
    }
    val sr = 62f * (1f + lvl * 0.12f)
    val sy = h - 34f
    clipRect(-170f, -170f, 170f, h) {
        val circ = m.path
        circ.reset()
        circ.addOval(Rect(-sr, sy - sr, sr, sy + sr))
        clipPath(circ) {
            val br = Brush.verticalGradient(0f to p.b, 1f to p.c, startY = sy - sr, endY = sy + sr)
            var y0 = sy - sr - 2f
            for (s in 0..5) {
                val gs = sy + 4f + s * 9f
                val ge = gs + 1.5f + s * 1.4f
                if (gs > y0) drawRect(br, Offset(-sr, y0), Size(2f * sr, gs - y0))
                y0 = ge
            }
            drawRect(br, Offset(-sr, y0), Size(2f * sr, sy + sr + 2f - y0))
        }
    }
    glow(f, 0f, sy, sr * 1.8f, p.c, 0.12f + lvl * 0.18f)
    drawLine(p.b.al(0.7f), Offset(-170f, h), Offset(170f, h), 1.4f)
    for (j in -12..12) {
        drawLine(p.a.mixW(0.3f).al(0.45f), Offset(j * 12f, h), Offset(j * 58f, 170f), 1f)
    }
    val spd = 0.4f * (1f + lvl * 2f) * (if (f.think) 2f else 1f)
    val path = m.path2
    for (k in 0..9) {
        val fr = (k + ((t * spd) % 1f)) / 10f
        val y = h + (170f - h) * fr * fr
        path.reset()
        var x = -170f
        var first = true
        while (x <= 170f) {
            val yy = y - lvl * 26f * fr * sin((x + 170f) * 0.045f + t * 6f)
            if (first) { path.moveTo(x, yy); first = false } else path.lineTo(x, yy)
            x += 12f
        }
        drawPath(path, p.a.mixW(0.3f).al(0.15f + 0.5f * fr), style = Stroke(1f))
    }
}
